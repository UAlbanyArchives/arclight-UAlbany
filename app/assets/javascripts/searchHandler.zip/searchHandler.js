document.addEventListener('DOMContentLoaded', function() {

    // URLs for Search form get request
    var allSearchURL = "http://lib-espy-ws-p101.its.albany.edu/search";
    var arclightSearchURL = "http://lib-espy-ws-p101.its.albany.edu/collections/catalog";
    var hyraxSearchURL = "http://lib-espy-ws-p101.its.albany.edu/repository/catalog/";

    //query selector for search form
    var searchForm = document.getElementsByClassName('allSearch');
    var searchPlaceholder = document.getElementById('q');
    var currentSelection = document.getElementById('currentSelection');


    //button query selectors
    var allSearchBtn = document.querySelector('a[data="allSearch"]');
    var arclightBtn = document.querySelector('a[data="arclightSarch"]');
    var hyraxBtn = document.querySelector('a[data="hyraxSearch"]');


    //
    //
    // Event Listeners - Search options change
    //
    //

    //Search all
    allSearchBtn.addEventListener('click', function() {
        searchForm.action = allSearchURL;
        searchPlaceholder.placeholder = "Search everything...";
        currentSelection.textContent = "Everything";
    });

    //Search Arclight
    arclightBtn.addEventListener('click', function() {
        searchForm.action = arclightSearchURL;
        searchPlaceholder.placeholder = "Search all collection records...";
        currentSelection.textContent = "Collections";
    });

    //Search Hyrax
    hyraxBtn.addEventListener('click', function() {
        searchForm.action = hyraxSearchURL;
        searchPlaceholder.placeholder = "Search only online digitcal content...";
        currentSelection.textContent = "Digital Selections";
    });


}, false);